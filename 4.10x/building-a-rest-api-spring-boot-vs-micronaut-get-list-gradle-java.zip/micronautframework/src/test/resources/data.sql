INSERT INTO saas_subscription(id, name, cents) VALUES (99, 'Advanced', 2900);
INSERT INTO saas_subscription(id, name, cents) VALUES (100, 'Essential', 1400);
INSERT INTO saas_subscription(id, name, cents) VALUES (101, 'Professional', 4900);
