/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut
import io.micronaut.http.*
import org.junit.jupiter.api.Test
import io.micronaut.gcp.function.http.*
import org.junit.jupiter.api.Assertions

class DefaultFunctionTest {

    @Test
    fun testFunction() {
        HttpFunction().use { function ->
           val response = function.invoke(HttpMethod.GET, "/default")
            Assertions.assertEquals(HttpStatus.OK, response.status)
        }
    }


    @Test
    fun testPost(){
        HttpFunction().use { function ->
            val input = SampleInputMessage("Test Name")
            val request = HttpRequest.POST("/default", input).contentType(MediaType.APPLICATION_JSON_TYPE)
            val response = function.invoke(request)
            Assertions.assertEquals(HttpStatus.OK, response.status)
        }
    }
}
