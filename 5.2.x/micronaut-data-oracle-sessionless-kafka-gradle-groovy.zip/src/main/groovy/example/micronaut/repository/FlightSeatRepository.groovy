/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut.repository

import groovy.transform.CompileStatic

import example.micronaut.dto.FlightSeatView
import example.micronaut.entity.FlightSeat
import example.micronaut.entity.SeatStatus

import io.micronaut.data.jdbc.annotation.JdbcRepository
import io.micronaut.data.model.query.builder.sql.Dialect
import io.micronaut.data.repository.CrudRepository
import java.util.Optional

@CompileStatic
@JdbcRepository(dialect = Dialect.ORACLE) // <1>
interface FlightSeatRepository extends CrudRepository<FlightSeat, String> { // <2>
    Optional<FlightSeat> findByIdAndStatusForUpdate(String id, SeatStatus status)
    Optional<FlightSeat> findByIdAndStatus(String id, SeatStatus status)
    Optional<FlightSeatView> queryById(String id) // <3>
}
