## Micronaut 5.2.0 Documentation

- [User Guide](https://docs.micronaut.io/5.2.0/guide/index.html)
- [API Reference](https://docs.micronaut.io/5.2.0/api/index.html)
- [Configuration Reference](https://docs.micronaut.io/5.2.0/guide/configurationreference.html)
- [Micronaut Guides](https://guides.micronaut.io/index.html)
---

- [Micronaut Maven Plugin documentation](https://micronaut-projects.github.io/micronaut-maven-plugin/latest/)
## Feature serialization-jackson documentation


- [Micronaut Serialization Jackson Core documentation](https://micronaut-projects.github.io/micronaut-serialization/latest/guide/)


## Feature spotless documentation


- [https://github.com/diffplug/spotless](https://github.com/diffplug/spotless)


## Feature graalpy documentation


- [Micronaut GraalPy Extension documentation](https://micronaut-projects.github.io/micronaut-graal-languages/latest/guide/)


- [https://graalvm.org/python](https://graalvm.org/python)


## Feature micronaut-aot documentation


- [Micronaut AOT documentation](https://micronaut-projects.github.io/micronaut-aot/latest/guide/)


## Feature maven-enforcer-plugin documentation


- [https://maven.apache.org/enforcer/maven-enforcer-plugin/](https://maven.apache.org/enforcer/maven-enforcer-plugin/)


