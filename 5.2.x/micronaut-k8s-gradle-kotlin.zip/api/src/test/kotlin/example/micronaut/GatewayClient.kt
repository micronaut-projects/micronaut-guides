/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut

import example.micronaut.models.Item
import example.micronaut.models.Order
import example.micronaut.models.User
import io.micronaut.http.annotation.Body
import io.micronaut.http.annotation.Get
import io.micronaut.http.annotation.Post
import io.micronaut.http.client.annotation.Client

@Client("/") // <1>
interface GatewayClient {
    @Get("/api/items/{id}")
    fun getItemById(id: Int?): Item?

    @Get("/api/orders/{id}")
    fun getOrderById(id: Int?): Order?

    @Get("/api/users/{id}")
    fun getUsersById(id: Int?): User?

    @get:Get("/api/users")
    val users: List<User>

    @get:Get("/api/items")
    val items: List<Item>

    @get:Get("/api/orders")
    val orders: List<Order>

    @Post("/api/orders")
    fun createOrder(@Body order: Order): Order

    @Post("/api/users")
    fun createUser(@Body user: User): User
}
