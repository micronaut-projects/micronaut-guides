/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut;

import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.client.BlockingHttpClient;
import io.micronaut.http.client.HttpClient;
import io.micronaut.http.client.annotation.Client;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS) // <1>
@MicronautTest // <2>
class BookControllerTest extends AbstractTest { // <3>

    @Test
    void bookUpsert(BookRepository repository, // <4>
                    @Client("/") HttpClient httpClient) { // <5>
        BlockingHttpClient client = httpClient.toBlocking();
        String path = "/books";
        String title = "Netty in Action";
        assertNull(repository.findByTitle(title)); // <6>
        HttpRequest<?> postRequest = HttpRequest.POST(path, Map.of("id", 123L, "title", title));
        HttpResponse<?> postResponse = assertDoesNotThrow(() -> client.exchange(postRequest));
        assertEquals(HttpStatus.CREATED, postResponse.getStatus()); // <7>
        assertNotNull(repository.findByTitle(title));
        assertNull(repository.findByTitle(title).pages());

        HttpRequest<?> putRequest = HttpRequest.PUT(path, Map.of("id", 123L, "title", title, "pages", 265));
        HttpResponse<?> putResponse = assertDoesNotThrow(() -> client.exchange(putRequest));
        assertEquals(HttpStatus.OK, putResponse.getStatus()); // <8>
        assertNotNull(repository.findByTitle(title).pages()); // <9>
    }

}