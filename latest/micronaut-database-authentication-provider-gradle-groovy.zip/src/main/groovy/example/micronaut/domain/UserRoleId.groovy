/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut.domain

import groovy.transform.EqualsAndHashCode
import io.micronaut.core.annotation.Creator
import jakarta.persistence.Embeddable
import io.micronaut.serde.annotation.Serdeable

@EqualsAndHashCode
@Serdeable // <1>
@Embeddable // <2>
class UserRoleId {
    final Long userId
    final Long roleId

    @Creator // <3>
    UserRoleId(Long userId,
               Long roleId) {
        this.userId = userId
        this.roleId = roleId
    }

    UserRoleId() {

    }
}
