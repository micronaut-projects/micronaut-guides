/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut

import example.micronaut.domain.StudentScheduleClassSubView
import example.micronaut.domain.StudentScheduleSubView
import example.micronaut.domain.StudentView
import io.micronaut.test.extensions.spock.annotation.MicronautTest
import jakarta.inject.Inject
import spock.lang.Specification

@MicronautTest
class StudentViewRepositorySpec extends Specification {

    @Inject
    StudentViewRepository studentViewRepository

    @Inject
    ClassRepository classRepository

    def "test create student view"() {
        when:
        def mathClass = classRepository.save(new example.micronaut.domain.Class(name: "Math"))
        def studentScheduleClassSubView = new StudentScheduleClassSubView(classID: mathClass.id, name: mathClass.name)
        def studentScheduleSubView = new StudentScheduleSubView(id: 0L, clazz: studentScheduleClassSubView)
        def studentView = new StudentView(name: "John", classes: [studentScheduleSubView], extras: [department: "Research", remote: true])
        studentViewRepository.save(studentView)
        def student = studentViewRepository.findByName(studentView.name)

        then:
        student.isPresent()
        student.get().extras.department == "Research"
        student.get().extras.remote == true
        student.get().classes.size() == 1
        student.get().classes[0].clazz.name == "Math"
    }
}
