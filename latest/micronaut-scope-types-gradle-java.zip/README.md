## Micronaut 5.0.2 Documentation

- [User Guide](https://docs.micronaut.io/5.0.2/guide/index.html)
- [API Reference](https://docs.micronaut.io/5.0.2/api/index.html)
- [Configuration Reference](https://docs.micronaut.io/5.0.2/guide/configurationreference.html)
- [Micronaut Guides](https://guides.micronaut.io/index.html)
---

- [Micronaut Gradle Plugin documentation](https://micronaut-projects.github.io/micronaut-gradle-plugin/latest/)
- [GraalVM Gradle Plugin documentation](https://graalvm.github.io/native-build-tools/latest/gradle-plugin.html)
- [Shadow Gradle Plugin](https://gradleup.com/shadow/)
## Feature junit-params documentation


- [https://junit.org/junit5/docs/current/user-guide/#writing-tests-parameterized-tests](https://junit.org/junit5/docs/current/user-guide/#writing-tests-parameterized-tests)


## Feature spotless documentation


- [https://github.com/diffplug/spotless](https://github.com/diffplug/spotless)


## Feature management documentation


- [Micronaut Management documentation](https://docs.micronaut.io/latest/guide/index.html#management)


## Feature serialization-jackson documentation


- [Micronaut Serialization Jackson Core documentation](https://micronaut-projects.github.io/micronaut-serialization/latest/guide/)


## Feature micronaut-aot documentation


- [Micronaut AOT documentation](https://micronaut-projects.github.io/micronaut-aot/latest/guide/)


## Feature validation documentation


- [Micronaut Validation documentation](https://micronaut-projects.github.io/micronaut-validation/latest/guide/)


