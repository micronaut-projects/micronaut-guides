package example.micronaut
import io.micronaut.core.annotation.Introspected

@Introspected
class Book {
    var name: String? = null
}