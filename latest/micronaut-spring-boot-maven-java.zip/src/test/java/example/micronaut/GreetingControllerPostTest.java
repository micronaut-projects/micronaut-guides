/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut;

import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@MicronautTest
class GreetingControllerPostTest {

    @Inject
    GreetingClient greetingClient;

    @Test
    void postWithRequestBodyAndPostMappingWorks() {
        Greeting request = new Greeting(99l, "Sergio");
        Greeting response = greetingClient.greetByPost(request) ;
        assertNotNull(response);
        assertNotEquals(request.getId(), response.getId());
        assertEquals("Hola, " + request.getContent() + "!", response.getContent());
    }
}
