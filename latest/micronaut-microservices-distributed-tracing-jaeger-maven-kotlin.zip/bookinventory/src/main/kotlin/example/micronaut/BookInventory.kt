package example.micronaut

data class BookInventory(var isbn: String, val stock: Int)