package example.micronaut

enum class PetType {
    DOG,
    CAT
}