INSERT INTO saas_subscription(id, name, cents, owner) VALUES (99, 'Advanced', 2900, 'sarah1');
INSERT INTO saas_subscription(id, name, cents, owner) VALUES (100, 'Essential', 1400, 'sarah1');
INSERT INTO saas_subscription(id, name, cents, owner) VALUES (101, 'Professional', 4900, 'sarah1');
INSERT INTO saas_subscription(id, name, cents, owner) VALUES (102, 'Enterprise', 9900, 'johnsnow');
