/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut

import io.micronaut.test.support.TestPropertyProvider
import org.testcontainers.containers.PostgreSQLContainer

abstract class AbstractTest : TestPropertyProvider { // <1>

    companion object {
        val postgres = PostgreSQLContainer<Nothing>("postgres:15.3-alpine") // <2>
    }

    override fun getProperties(): Map<String, String> {
        if (!postgres.isRunning) {
            postgres.start() // <3>
        }
        return mapOf(
            "datasources.default.driver-class-name" to "org.postgresql.Driver", // <4>
            "datasources.default.url" to postgres.jdbcUrl,
            "datasources.default.username" to postgres.username,
            "datasources.default.password" to postgres.password
        )
    }
}
