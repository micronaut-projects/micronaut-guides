/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut

import groovy.transform.CompileStatic
import io.micronaut.http.annotation.Controller
import io.micronaut.http.annotation.Get
import io.micronaut.http.annotation.Header
import io.micronaut.http.annotation.Produces
import io.micronaut.security.annotation.Secured
import reactor.core.publisher.Mono

import static io.micronaut.http.MediaType.TEXT_PLAIN
import static io.micronaut.security.rules.SecurityRule.IS_AUTHENTICATED

@CompileStatic
@Controller('/user') // <1>
class UserController {

    private final UsernameFetcher usernameFetcher

    UserController(UsernameFetcher usernameFetcher) {  // <2>
        this.usernameFetcher = usernameFetcher
    }

    @Secured(IS_AUTHENTICATED)  // <3>
    @Produces(TEXT_PLAIN) // <4>
    @Get// <5>
    Mono<String> index(@Header('Authorization') String authorization) {  // <6>
        return usernameFetcher.findUsername(authorization)
    }
}
