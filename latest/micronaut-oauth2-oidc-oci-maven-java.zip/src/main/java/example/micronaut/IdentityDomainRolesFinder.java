/*
 * Copyright 2017-2025 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut;

import io.micronaut.context.annotation.Replaces;
import io.micronaut.core.annotation.NonNull;
import io.micronaut.core.annotation.Nullable;
import io.micronaut.core.util.StringUtils;
import io.micronaut.json.JsonMapper;
import io.micronaut.security.token.RolesFinder;
import io.micronaut.security.token.config.TokenConfiguration;
import jakarta.inject.Singleton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Singleton // <1>
@Replaces(RolesFinder.class)
public class IdentityDomainRolesFinder implements RolesFinder {
    private static final String KEY_NAME = "name";
    private final TokenConfiguration tokenConfiguration;

    public IdentityDomainRolesFinder(TokenConfiguration tokenConfiguration,
                                     JsonMapper jsonMapper) {
        this.tokenConfiguration = tokenConfiguration;
    }

    @Override
    public @NonNull List<String> resolveRoles(@Nullable Map<String, Object> attributes) {
        if (!attributes.containsKey(tokenConfiguration.getRolesName())) {
            return Collections.emptyList();
        }
        Object obj = attributes.get(tokenConfiguration.getRolesName());
        if (obj == null) {
            return Collections.emptyList();
        }
        if (obj instanceof Iterable objIterable) {
            List<String> roles = new ArrayList<>();
            for(Object o : objIterable) {
                if (o instanceof Map m) {
                    Object name = m.get(KEY_NAME);
                    if (name != null) {
                        String nameValue = name.toString();
                        if (StringUtils.isNotEmpty(nameValue)) {
                            roles.add(nameValue);
                        }
                    }
                }
            }
            return roles;
        }
        return Collections.emptyList();
    }
}
