package example.micronaut

import java.util.ArrayList

class TemperatureScaleCandidates : ArrayList<String>(Scale.candidates())
