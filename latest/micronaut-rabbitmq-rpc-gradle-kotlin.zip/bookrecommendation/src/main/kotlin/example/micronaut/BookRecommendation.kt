package example.micronaut

import io.micronaut.core.annotation.Introspected

@Introspected
class BookRecommendation(val name: String)
