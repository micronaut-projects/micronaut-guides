package example.twitter.api;

import example.twitter.model.Error;
import example.twitter.model.MultiSpaceLookupResponse;
import example.twitter.model.Problem;
import java.util.Set;
import example.twitter.model.SingleSpaceLookupResponse;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import jakarta.inject.Inject;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.HashSet;


/**
 * API tests for SpacesApi
 */
@MicronautTest
public class SpacesApiTest {

    @Inject
    SpacesApi api;

    
    /**
     * Space lookup by Space ID
     *
     * Returns a variety of information about the Space specified by the requested ID
     */
    @Test
    @Disabled("Not Implemented")
    public void findSpaceByIdTest() {
        // given
        String id = "example";
        Set<String> spaceFields = new HashSet<>();
        Set<String> expansions = new HashSet<>();

        // when
        SingleSpaceLookupResponse body = api.findSpaceById(id, spaceFields, expansions).block();

        // then
        // TODO implement the findSpaceByIdTest()
    }

    
    /**
     * Space lookup by their creators
     *
     * Returns a variety of information about the Spaces created by the provided User IDs
     */
    @Test
    @Disabled("Not Implemented")
    public void findSpacesByCreatorIdsTest() {
        // given
        List<String> userIds = Arrays.asList("example");
        Set<String> spaceFields = new HashSet<>();
        Set<String> expansions = new HashSet<>();

        // when
        MultiSpaceLookupResponse body = api.findSpacesByCreatorIds(userIds, spaceFields, expansions).block();

        // then
        // TODO implement the findSpacesByCreatorIdsTest()
    }

    
    /**
     * Space lookup up Space IDs
     *
     * Returns a variety of information about the Spaces specified by the requested IDs
     */
    @Test
    @Disabled("Not Implemented")
    public void findSpacesByIdsTest() {
        // given
        List<String> ids = Arrays.asList("example");
        Set<String> spaceFields = new HashSet<>();
        Set<String> expansions = new HashSet<>();

        // when
        MultiSpaceLookupResponse body = api.findSpacesByIds(ids, spaceFields, expansions).block();

        // then
        // TODO implement the findSpacesByIdsTest()
    }

    
    /**
     * Search for Spaces
     *
     * Returns Spaces that match the provided query.
     */
    @Test
    @Disabled("Not Implemented")
    public void searchSpacesTest() {
        // given
        String query = "crypto";
        String state = "live";
        Integer maxResults = 25;
        Set<String> spaceFields = new HashSet<>();
        Set<String> expansions = new HashSet<>();

        // when
        MultiSpaceLookupResponse body = api.searchSpaces(query, state, maxResults, spaceFields, expansions).block();

        // then
        // TODO implement the searchSpacesTest()
    }

    
}
