package example.micronaut;

public enum BuildTool {

    GRADLE, MAVEN
}
