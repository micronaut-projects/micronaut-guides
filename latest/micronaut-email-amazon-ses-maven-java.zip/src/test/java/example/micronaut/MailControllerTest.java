/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut;

import io.micronaut.context.BeanContext;
import io.micronaut.context.annotation.Property;
import io.micronaut.core.util.CollectionUtils;
import io.micronaut.email.AsyncTransactionalEmailSender;
import io.micronaut.email.BodyType;
import io.micronaut.email.Email;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.client.HttpClient;
import io.micronaut.http.client.annotation.Client;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

import java.util.Collections;

import static io.micronaut.http.HttpStatus.ACCEPTED;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@Property(name = "spec.name", value = "MailControllerTest") // <1>
@MicronautTest // <2>
public class MailControllerTest {

    @Inject
    @Client("/")
    HttpClient httpClient; // <3>

    @Inject
    BeanContext beanContext;

    @Test
    void getMailSendEndpointSendsAnEmail() {

        HttpResponse<?> response = httpClient.toBlocking().exchange(
                HttpRequest.POST("/mail/send",
                Collections.singletonMap("to", "johnsnow@micronaut.example")));
        assertEquals(ACCEPTED, response.status());

        AsyncTransactionalEmailSender<?, ?> sender = beanContext.getBean(AsyncTransactionalEmailSender.class);
        assertTrue(sender instanceof EmailSenderReplacement);

        EmailSenderReplacement sendgridSender = (EmailSenderReplacement) sender;
        assertTrue(CollectionUtils.isNotEmpty(sendgridSender.getEmails()));
        assertEquals(1, sendgridSender.getEmails().size());

        Email email = sendgridSender.getEmails().get(0);
        assertEquals(email.getFrom().getEmail(), "john@micronaut.example");
        assertNotNull(email.getTo());
        assertTrue(email.getTo().stream().findFirst().isPresent());
        assertEquals(email.getTo().stream().findFirst().get().getEmail(), "johnsnow@micronaut.example");
        assertEquals(email.getSubject(), "Sending email with Amazon SES is Fun");
        assertNotNull(email.getBody());
        assertTrue(email.getBody().get(BodyType.HTML).isPresent());
        assertEquals(email.getBody().get(BodyType.HTML).get(), "and <em>easy</em> to do anywhere with <strong>Micronaut Email</strong>");
    }
}
