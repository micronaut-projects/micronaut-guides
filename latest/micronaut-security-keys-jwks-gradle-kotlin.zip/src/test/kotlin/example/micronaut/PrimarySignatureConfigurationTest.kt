/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut

import io.micronaut.context.ApplicationContext
import io.micronaut.core.annotation.AnnotationUtil.NAMED
import io.micronaut.runtime.context.scope.Refreshable
import io.micronaut.test.extensions.junit5.annotation.MicronautTest
import jakarta.inject.Inject
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

@MicronautTest(startApplication = false)
class PrimarySignatureConfigurationTest {

    @Inject
    lateinit var applicationContext: ApplicationContext

    @Test
    fun primarySignatureConfigurationIsAnnotatedWithRefreshable() {
        assertTrue(applicationContext.getBeanDefinition(PrimarySignatureConfiguration::class.java)
            .getAnnotationNameByStereotype(Refreshable::class.java)
            .isPresent)
    }

    @Test
    fun primarySignatureConfigurationIsAnnotatedNamedGenerator() {
        assertNotNull(applicationContext.getBeanDefinition(PrimarySignatureConfiguration::class.java).annotationMetadata
            .getAnnotation<Annotation>(NAMED))

        assertTrue(
            applicationContext.getBeanDefinition(PrimarySignatureConfiguration::class.java).annotationMetadata
                .getAnnotation<Annotation>(NAMED)
                ?.getValue(String::class.java)?.isPresent ?: false
        )

        assertEquals("generator", applicationContext.getBeanDefinition(PrimarySignatureConfiguration::class.java).annotationMetadata
            .getAnnotation<Annotation>(NAMED)
            ?.getValue(String::class.java)?.get()
        )
    }
}
