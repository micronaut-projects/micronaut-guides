import pytest

from pyronaut.test import *

@pytest.fixture
def my_context(request):
    fixture = micronaut_test_fixture(request, MicronautTest(environments=["test"], transactional=False))
    yield fixture
    fixture.stop()

def test_context(my_context):
    assert my_context.isRunning()
