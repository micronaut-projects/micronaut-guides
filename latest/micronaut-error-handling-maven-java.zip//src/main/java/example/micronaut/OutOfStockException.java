package example.micronaut;

public class OutOfStockException extends RuntimeException {
}
