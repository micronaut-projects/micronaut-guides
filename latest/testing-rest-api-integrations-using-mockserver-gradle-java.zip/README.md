## Micronaut 4.3.4 Documentation

- [User Guide](https://docs.micronaut.io/4.3.4/guide/index.html)
- [API Reference](https://docs.micronaut.io/4.3.4/api/index.html)
- [Configuration Reference](https://docs.micronaut.io/4.3.4/guide/configurationreference.html)
- [Micronaut Guides](https://guides.micronaut.io/index.html)
---

- [Micronaut Gradle Plugin documentation](https://micronaut-projects.github.io/micronaut-gradle-plugin/latest/)
- [GraalVM Gradle Plugin documentation](https://graalvm.github.io/native-build-tools/latest/gradle-plugin.html)
- [Shadow Gradle Plugin](https://plugins.gradle.org/plugin/com.github.johnrengelman.shadow)
## Feature micronaut-aot documentation

- [Micronaut AOT documentation](https://micronaut-projects.github.io/micronaut-aot/latest/guide/)


## Feature http-client documentation

- [Micronaut HTTP Client documentation](https://docs.micronaut.io/latest/guide/index.html#nettyHttpClient)


## Feature mockserver-client-java documentation

- [https://www.mock-server.com/mock_server/mockserver_clients.html#java-mockserver-client](https://www.mock-server.com/mock_server/mockserver_clients.html#java-mockserver-client)


## Feature spotless documentation

- [https://github.com/diffplug/spotless](https://github.com/diffplug/spotless)


## Feature micronaut-test-rest-assured documentation

- [Micronaut Micronaut-Test REST-assured documentation](https://micronaut-projects.github.io/micronaut-test/latest/guide/#restAssured)

- [https://rest-assured.io/#docs](https://rest-assured.io/#docs)


## Feature serialization-jackson documentation

- [Micronaut Serialization Jackson Core documentation](https://micronaut-projects.github.io/micronaut-serialization/latest/guide/)


## Feature testcontainers documentation

- [https://www.testcontainers.org/](https://www.testcontainers.org/)


