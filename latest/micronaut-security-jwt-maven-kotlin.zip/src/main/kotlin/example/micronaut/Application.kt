package example.micronaut

import io.micronaut.runtime.Micronaut.*

fun main(args: Array<String>) {
	run(*args)
}

