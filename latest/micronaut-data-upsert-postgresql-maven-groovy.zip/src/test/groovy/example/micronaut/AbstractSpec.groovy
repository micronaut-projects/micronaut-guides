/*
 * Copyright 2017-2026 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package example.micronaut

import io.micronaut.core.annotation.NonNull
import io.micronaut.test.support.TestPropertyProvider
import org.testcontainers.containers.PostgreSQLContainer
import spock.lang.Specification

abstract class AbstractSpec extends Specification implements TestPropertyProvider { // <1>

    static PostgreSQLContainer postgres = new PostgreSQLContainer('postgres:15.3-alpine') // <2>

    @Override
    @NonNull
    Map<String, String> getProperties() {
        if (!postgres.running) {
            postgres.start() // <3>
        }
        [
                'datasources.default.driver-class-name': 'org.postgresql.Driver', // <4>
                'datasources.default.url'              : postgres.jdbcUrl,
                'datasources.default.username'         : postgres.username,
                'datasources.default.password'         : postgres.password,
        ]
    }
}
