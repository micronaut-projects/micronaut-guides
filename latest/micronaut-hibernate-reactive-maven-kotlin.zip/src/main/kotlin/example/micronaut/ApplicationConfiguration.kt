package example.micronaut

interface ApplicationConfiguration {
    val max: Int
}