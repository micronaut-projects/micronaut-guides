## Micronaut 3.8.2 Documentation

- [User Guide](https://docs.micronaut.io/3.8.2/guide/index.html)
- [API Reference](https://docs.micronaut.io/3.8.2/api/index.html)
- [Configuration Reference](https://docs.micronaut.io/3.8.2/guide/configurationreference.html)
- [Micronaut Guides](https://guides.micronaut.io/index.html)
---

- [Shadow Gradle Plugin](https://plugins.gradle.org/plugin/com.github.johnrengelman.shadow)
## Feature management documentation

- [Micronaut Management documentation](https://docs.micronaut.io/latest/guide/index.html#management)


## Feature multi-tenancy-gorm documentation

- [Micronaut Multitenancy GORM documentation](https://docs.micronaut.io/latest/guide/index.html#multitenancyGorm)

- [https://gorm.grails.org/latest/hibernate/manual/index.html#multiTenancy](https://gorm.grails.org/latest/hibernate/manual/index.html#multiTenancy)


## Feature http-client documentation

- [Micronaut HTTP Client documentation](https://docs.micronaut.io/latest/guide/index.html#httpClient)


## Feature hibernate-validator documentation

- [Micronaut Hibernate Validator documentation](https://micronaut-projects.github.io/micronaut-hibernate-validator/latest/guide/index.html)


## Feature multi-tenancy documentation

- [Micronaut Multitenancy documentation](https://docs.micronaut.io/latest/guide/index.html#multitenancy)


