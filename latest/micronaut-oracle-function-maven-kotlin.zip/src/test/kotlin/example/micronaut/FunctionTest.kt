package example.micronaut
import com.fnproject.fn.testing.FnTestingRule
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.Assertions.assertNotNull

class FunctionTest {
    @Test
    fun testFunction() {
        val rule = FnTestingRule.createDefault()
        rule.givenEvent().enqueue()
        rule.thenRun(Function::class.java, "handleRequest")
        val result = rule.onlyResult.bodyAsString
        assertNotNull(result)
    }
}
