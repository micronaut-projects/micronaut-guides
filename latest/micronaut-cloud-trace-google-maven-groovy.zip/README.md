## Micronaut 5.0.0 Documentation

- [User Guide](https://docs.micronaut.io/5.0.0/guide/index.html)
- [API Reference](https://docs.micronaut.io/5.0.0/api/index.html)
- [Configuration Reference](https://docs.micronaut.io/5.0.0/guide/configurationreference.html)
- [Micronaut Guides](https://guides.micronaut.io/index.html)
---

- [Micronaut Maven Plugin documentation](https://micronaut-projects.github.io/micronaut-maven-plugin/latest/)
## Feature serialization-jackson documentation


- [Micronaut Serialization Jackson Core documentation](https://micronaut-projects.github.io/micronaut-serialization/latest/guide/)


## Feature tracing-opentelemetry-annotations documentation


- [Micronaut OpenTelemetry Annotations documentation](https://micronaut-projects.github.io/micronaut-tracing/latest/guide/#opentelemetry)


- [https://opentelemetry.io](https://opentelemetry.io)


## Feature tracing-opentelemetry-http documentation


- [Micronaut OpenTelemetry HTTP documentation](http://localhost/micronaut-tracing/guide/index.html#opentelemetry)


## Feature spotless documentation


- [https://github.com/diffplug/spotless](https://github.com/diffplug/spotless)


## Feature groovy-maven-plus-plugin documentation


- [https://github.com/groovy/GMavenPlus/wiki/Usage](https://github.com/groovy/GMavenPlus/wiki/Usage)


## Feature http-client documentation


- [Micronaut HTTP Client documentation](https://docs.micronaut.io/latest/guide/index.html#nettyHttpClient)


## Feature tracing-opentelemetry-gcp documentation


- [Micronaut OpenTelemetry Google Cloud Trace documentation](https://micronaut-projects.github.io/micronaut-tracing/latest/guide/#opentelemetry)


- [https://opentelemetry.io](https://opentelemetry.io)


## Feature micronaut-aot documentation


- [Micronaut AOT documentation](https://micronaut-projects.github.io/micronaut-aot/latest/guide/)


## Feature maven-enforcer-plugin documentation


- [https://maven.apache.org/enforcer/maven-enforcer-plugin/](https://maven.apache.org/enforcer/maven-enforcer-plugin/)


## Feature tracing-opentelemetry-exporter-gcp documentation


- [Micronaut OpenTelemetry Exporter gcp documentation](http://localhost/micronaut-tracing/guide/index.html#opentelemetry)


- [https://opentelemetry.io](https://opentelemetry.io)


