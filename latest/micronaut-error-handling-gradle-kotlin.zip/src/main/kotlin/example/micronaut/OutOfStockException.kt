package example.micronaut

class OutOfStockException: RuntimeException()