CREATE TABLE person(
    id   bigint primary key not null,
    name varchar(255)       not null,
    age  int                not null
)
