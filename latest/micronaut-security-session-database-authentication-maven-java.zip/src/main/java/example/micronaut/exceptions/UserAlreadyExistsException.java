package example.micronaut.exceptions;

public class UserAlreadyExistsException extends RuntimeException {
}
