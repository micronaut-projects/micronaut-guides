package example.micronaut

data class BintrayPackage(var name: String = "",
                          var linked: Boolean = false) {
}