package example.micronaut

interface ApplicationConfiguration {
    val hostedDomain: String
}
