package example.micronaut;

import io.micronaut.http.annotation.*;

@Controller("/default")
public class DefaultController {

    @Get(uri="/", produces="text/plain")
    public String index() {
        return "Example Response";
    }
}