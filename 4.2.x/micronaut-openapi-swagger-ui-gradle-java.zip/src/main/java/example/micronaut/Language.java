package example.micronaut;

public enum Language {

    GROOVY,
    JAVA,
    KOTLIN
}
