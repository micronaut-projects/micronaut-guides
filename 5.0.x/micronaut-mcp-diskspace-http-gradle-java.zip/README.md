## Micronaut 5.0.2 Documentation

- [User Guide](https://docs.micronaut.io/5.0.2/guide/index.html)
- [API Reference](https://docs.micronaut.io/5.0.2/api/index.html)
- [Configuration Reference](https://docs.micronaut.io/5.0.2/guide/configurationreference.html)
- [Micronaut Guides](https://guides.micronaut.io/index.html)
---

- [Micronaut Gradle Plugin documentation](https://micronaut-projects.github.io/micronaut-gradle-plugin/latest/)
- [GraalVM Gradle Plugin documentation](https://graalvm.github.io/native-build-tools/latest/gradle-plugin.html)
- [Shadow Gradle Plugin](https://gradleup.com/shadow/)
## Feature mcp-client-java-sdk documentation


- [Micronaut Mcp Client Java SDK documentation](https://micronaut-projects.github.io/micronaut-mcp/latest/guide)


- [https://modelcontextprotocol.io/sdk/java/mcp-overview](https://modelcontextprotocol.io/sdk/java/mcp-overview)


## Feature mcp-http documentation


- [Micronaut MCP HTTP documentation](https://micronaut-projects.github.io/micronaut-mcp/latest/guide/#server)


- [https://modelcontextprotocol.io](https://modelcontextprotocol.io)


## Feature serialization-jackson documentation


- [Micronaut Serialization Jackson Core documentation](https://micronaut-projects.github.io/micronaut-serialization/latest/guide/)


## Feature micronaut-aot documentation


- [Micronaut AOT documentation](https://micronaut-projects.github.io/micronaut-aot/latest/guide/)


## Feature spotless documentation


- [https://github.com/diffplug/spotless](https://github.com/diffplug/spotless)


