

package example.micronaut

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SpringbootTest {
	@Test
	fun contextLoads() {
	}
}
