## Micronaut 3.2.7 Documentation

- [User Guide](https://docs.micronaut.io/3.2.7/guide/index.html)
- [API Reference](https://docs.micronaut.io/3.2.7/api/index.html)
- [Configuration Reference](https://docs.micronaut.io/3.2.7/guide/configurationreference.html)
- [Micronaut Guides](https://guides.micronaut.io/index.html)
---

## Feature reactor documentation

- [Micronaut Reactor documentation](https://micronaut-projects.github.io/micronaut-reactor/snapshot/guide/index.html)

## Feature management documentation

- [Micronaut Management documentation](https://docs.micronaut.io/latest/guide/index.html#management)

## Feature tracing-jaeger documentation

- [Micronaut Jaeger Tracing documentation](https://docs.micronaut.io/latest/guide/index.html#jaeger)

- [https://www.jaegertracing.io](https://www.jaegertracing.io)

## Feature http-client documentation

- [Micronaut HTTP Client documentation](https://docs.micronaut.io/latest/guide/index.html#httpClient)

