ALTER TABLE person MODIFY age int default null;
