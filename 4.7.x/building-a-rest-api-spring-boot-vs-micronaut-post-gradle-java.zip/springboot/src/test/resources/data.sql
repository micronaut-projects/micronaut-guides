INSERT INTO saas_subscription(id, name, cents) VALUES (99, 'Advanced', 2900);
