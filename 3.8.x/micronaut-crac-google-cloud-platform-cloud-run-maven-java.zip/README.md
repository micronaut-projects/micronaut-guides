## Micronaut 3.8.9 Documentation

- [User Guide](https://docs.micronaut.io/3.8.9/guide/index.html)
- [API Reference](https://docs.micronaut.io/3.8.9/api/index.html)
- [Configuration Reference](https://docs.micronaut.io/3.8.9/guide/configurationreference.html)
- [Micronaut Guides](https://guides.micronaut.io/index.html)
---

## Feature crac documentation

- [Micronaut Support for CRaC (Coordinated Restore at Checkpoint) documentation](https://micronaut-projects.github.io/micronaut-crac/latest/guide)

- [https://wiki.openjdk.org/display/CRaC](https://wiki.openjdk.org/display/CRaC)


## Feature http-client documentation

- [Micronaut HTTP Client documentation](https://docs.micronaut.io/latest/guide/index.html#httpClient)


