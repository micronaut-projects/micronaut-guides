def hello(txt): # <1>
    return f"Hello {txt}"