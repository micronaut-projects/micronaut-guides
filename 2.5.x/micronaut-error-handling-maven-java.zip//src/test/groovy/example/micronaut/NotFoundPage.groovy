package example.micronaut

import geb.Page

class NotFoundPage extends Page {

    static at = { title == 'Not Found'}
}
