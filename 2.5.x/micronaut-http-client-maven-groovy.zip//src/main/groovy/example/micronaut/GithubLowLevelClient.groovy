package example.micronaut

import groovy.transform.CompileStatic
import io.micronaut.core.type.Argument
import io.micronaut.http.HttpRequest
import io.micronaut.http.client.RxHttpClient
import io.micronaut.http.client.annotation.Client
import io.micronaut.http.uri.UriBuilder
import org.reactivestreams.Publisher
import io.micronaut.core.async.annotation.SingleResult
import javax.inject.Singleton
import static io.micronaut.http.HttpHeaders.ACCEPT
import static io.micronaut.http.HttpHeaders.USER_AGENT

@Singleton // <1>
@CompileStatic
class GithubLowLevelClient {

    private final RxHttpClient httpClient
    private final URI uri

    GithubLowLevelClient(@Client(GithubConfiguration.GITHUB_API_URL) RxHttpClient httpClient,  // <2>
                         GithubConfiguration configuration) {  // <3>
        this.httpClient = httpClient
        this.uri = UriBuilder.of("/repos")
            .path(configuration.getOrganization())
            .path(configuration.getRepo())
            .path("releases")
            .build()
    }

    @SingleResult
    Publisher<List<GithubRelease>> fetchReleases() {
        HttpRequest<?> req = HttpRequest.GET(uri) // <4>
            .header(USER_AGENT, "Micronaut HTTP Client") // <5>
            .header(ACCEPT, "application/vnd.github.v3+json, application/json") // <6>
        httpClient.retrieve(req, Argument.listOf(GithubRelease)) // <7>
    }
}
